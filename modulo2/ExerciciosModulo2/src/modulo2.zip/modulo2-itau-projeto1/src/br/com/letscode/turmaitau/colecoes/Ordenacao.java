package br.com.letscode.turmaitau.colecoes;

public interface Ordenacao extends Comparable {
}
