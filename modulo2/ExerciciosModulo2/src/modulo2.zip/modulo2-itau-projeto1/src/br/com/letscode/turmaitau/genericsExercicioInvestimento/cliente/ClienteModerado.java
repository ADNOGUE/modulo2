package br.com.letscode.turmaitau.genericsExercicioInvestimento.cliente;

import br.com.letscode.turmaitau.genericsExercicioInvestimento.investimento.Investimento;
import br.com.letscode.turmaitau.genericsExercicioInvestimento.perfil.Moderado;


public class ClienteModerado extends Cliente<Moderado, Investimento> {
}
