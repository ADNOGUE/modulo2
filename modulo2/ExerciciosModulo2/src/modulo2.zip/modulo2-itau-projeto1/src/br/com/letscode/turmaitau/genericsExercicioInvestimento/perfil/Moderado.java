package br.com.letscode.turmaitau.genericsExercicioInvestimento.perfil;

public class Moderado implements ClientePerfil {
}
