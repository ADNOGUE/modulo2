package br.com.letscode.turmaitau.genericsExercicioInvestimento.perfil;

public interface ClientePerfil {

}
