package br.com.letscode.turmaitau.interfaces;

public class TesteInterfaceMain {

    public static void main(String[] args) {

        //PrimeiraInterface primeiraInterface = new PrimeiraInterface();

    }

}
