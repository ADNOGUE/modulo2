package br.com.letscode.turmaitau.genericsExercicioInvestimento.perfil;

public class Arrojado implements ClientePerfil {
}
