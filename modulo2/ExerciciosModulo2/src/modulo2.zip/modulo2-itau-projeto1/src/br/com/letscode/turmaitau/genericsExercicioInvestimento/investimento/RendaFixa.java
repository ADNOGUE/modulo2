package br.com.letscode.turmaitau.genericsExercicioInvestimento.investimento;

public class RendaFixa extends Investimento {
}
