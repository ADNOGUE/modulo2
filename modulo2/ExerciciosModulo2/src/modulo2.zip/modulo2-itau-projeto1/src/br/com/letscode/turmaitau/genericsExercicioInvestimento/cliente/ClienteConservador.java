package br.com.letscode.turmaitau.genericsExercicioInvestimento.cliente;

import br.com.letscode.turmaitau.genericsExercicioInvestimento.investimento.RendaFixa;
import br.com.letscode.turmaitau.genericsExercicioInvestimento.perfil.Conservador;


public class ClienteConservador extends Cliente<Conservador, RendaFixa> {
}
