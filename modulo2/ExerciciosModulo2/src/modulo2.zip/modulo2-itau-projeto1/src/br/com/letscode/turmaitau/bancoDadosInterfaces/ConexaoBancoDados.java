package br.com.letscode.turmaitau.bancoDadosInterfaces;

import br.com.letscode.turmaitau.genericsExercicioInvestimento.cliente.Cliente;

public class ConexaoBancoDados implements ConexaoDadosClientes {

    @Override
    public void criarCliente() {
        //consultar banco de dados
    }

    @Override
    public Cliente consultarCliente() {
        return null;
    }

}
