package br.com.letscode.turmaitau.genericsExercicioInvestimento.investimento;

public class FundoImobiliario extends RendaVariavel {
}
