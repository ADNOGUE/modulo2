package br.com.letscode.turmaitau.genericsExercicioInvestimento.investimento;

public class CDB extends RendaFixa {
}
