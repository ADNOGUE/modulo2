package br.com.letscode.turmaitau.genericsExercicioInvestimento.cliente;

import br.com.letscode.turmaitau.genericsExercicioInvestimento.investimento.RendaVariavel;
import br.com.letscode.turmaitau.genericsExercicioInvestimento.perfil.Arrojado;


public class ClienteArrojado extends Cliente<Arrojado, RendaVariavel> {

}
