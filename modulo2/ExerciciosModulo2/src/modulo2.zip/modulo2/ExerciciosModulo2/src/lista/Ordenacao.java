package lista;

public interface Ordenacao extends Comparable {
}
